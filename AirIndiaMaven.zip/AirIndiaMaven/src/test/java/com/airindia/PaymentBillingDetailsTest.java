package com.airindia;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.beust.jcommander.Parameter;

public class PaymentBillingDetailsTest extends CodeBaseAI{
	
	@BeforeClass
	public void startExtentLogger()
	{
		extentlogger = extentreports.createTest("PaymentBillingDetailsTest"); 
	}
	
	
	@Test
	public void test3() throws InterruptedException, IOException {
		
		extentlogger = extentreports.createTest("Air India search payment and billing details test 3");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));
		
		driver.findElement(By.id("from")).sendKeys("Delhi, Indira Gandhi International Airport, DEL, India");
		driver.findElement(By.id("to")).sendKeys("Hyderabad, Rajiv Gandhi International Airport, HYD, India");
		
		driver.findElement(By.xpath("(//ins[@class='iCheck-helper'])[1]")).click();
		driver.findElement(By.xpath("(//img[@alt='Date Picker'])[1]")).click();
		driver.findElement(By.xpath("//a[text()=\"16\"]")).click();

		WebElement dropdown=driver.findElement(By.id("ddladult1"));
		dropdown.click();
		Select sel=new Select(dropdown);
		sel.selectByVisibleText("1");
		
		driver.findElement(By.xpath("(//input[@type='submit'])[4]")).click();
		
		Reporter.log("Expand fare list button click");
		extentlogger.log(Status.INFO, "Expand fare list button clicked - Passed");
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//i[@aria-label='Expand fare list.']")));
		driver.findElement(By.xpath("//i[@aria-label='Expand fare list.']")).click();
		
		screenCapture();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//i[@aria-hidden='true'])[6]")));
		driver.findElement(By.xpath("(//i[@aria-hidden='true'])[6]")).click();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Continue']")));
		driver.findElement(By.xpath("//span[text()='Continue']")).click();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Keep Super Value Economy']")));
		driver.findElement(By.xpath("//span[text()='Keep Super Value Economy']")).click();
		
		Reporter.log("Fill passenger details button click");
		extentlogger.log(Status.INFO, "Fill passenger details button clicked - Passed");
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Fill passenger details']")));
		driver.findElement(By.xpath("//span[text()='Fill passenger details']")).click();
		
		screenCapture();
		
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//input[@formcontrolname='firstName']")));
		driver.findElement(By.xpath("//input[@formcontrolname='firstName']")).sendKeys("Sam");

		driver.findElement(By.xpath("//input[@formcontrolname='lastName']")).sendKeys("Nik");
		driver.findElement(By.xpath("//button[@aria-label=\"Open calendar\"]")).sendKeys("21/04/2001");

		driver.findElement(By.xpath("(//input[@type=\"email\"])[1]")).sendKeys("nikkysammathew8@gmail.com");

		driver.findElement(By.xpath("(//input[@type=\"email\"])[2]")).sendKeys("nikkysammathew8@gmail.com");

		driver.findElement(By.xpath("//input[@aria-describedby=\"countryCodes\"]")).sendKeys("+91");

		driver.findElement(By.xpath("//input[@type=\"tel\"]")).sendKeys("7012533828");
		
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("(//span[@class='mat-checkbox-inner-container'])[1]")));
		driver.findElement(By.xpath("(//span[@class='mat-checkbox-inner-container'])[1]")).click();
		
		Reporter.log("Confirm button click");
		extentlogger.log(Status.INFO, "Confirm button clicked - Passed");
		driver.findElement(By.xpath("//span[text()='Confirm']")).click();
		Thread.sleep(3000);
		
		screenCapture();
		Reporter.log("Redirection to traveler page.");
		extentlogger.log(Status.INFO, "Redirected to traveler page - Passed");
		
		String title = driver.getTitle();
		assertEquals(title, "Traveler", "Traveler Page Loaded - Test Passed");
		
		

	}

}

