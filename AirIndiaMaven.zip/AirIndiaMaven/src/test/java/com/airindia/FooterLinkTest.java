package com.airindia;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

public class FooterLinkTest extends CodeBaseAI {
	
	@BeforeClass
	public void startExtentLogger()
	{
		extentlogger = extentreports.createTest("FooterLinkTest"); 
	}
	
	@Test()
	public void test6() {
		
		
		extentlogger = extentreports.createTest("Air India Footer link test 6.");
		
		WebElement footer= driver.findElement(By.xpath("/html/body/form[1]/div[4]/div/div[13]"));
		
		Reporter.log("Verifying footer links."); 
		extentlogger.log(Status.INFO,"Footer links verified - Passed");
		
		List<WebElement> links = footer.findElements(By.tagName("a"));
		System.out.println("Total Number of links = "+ links.size() +" "+ "links");
		for (WebElement alllink :links) 
		{
		System.out.println(alllink.getAttribute("href"));
		System.out.println(alllink.getText());
		}
		
	}
}
