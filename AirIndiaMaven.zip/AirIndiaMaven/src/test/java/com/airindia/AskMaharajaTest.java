package com.airindia;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

public class AskMaharajaTest extends CodeBaseAI {
	
	@BeforeClass
	public void startExtentLogger()
	{
		extentlogger = extentreports.createTest("AskMaharajaTest"); 
	}
	
	@Test()
	public void test4() throws IOException {
		extentlogger = extentreports.createTest("Air India Ask Maharaja feature test 4.");
		
	
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,750)", "");
		
		Reporter.log("Clicking AskMaharaja button"); 
		extentlogger.log(Status.INFO,"AskMaharaja button clicked - Passed");

		driver.findElement(By.cssSelector(".uiButton.helpButtonEnabled")).click();
		screenCapture();
		
		Reporter.log("Clicking CovidInfo button"); 
		extentlogger.log(Status.INFO,"CovidInfo button clicked - Passed");
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[9]/div/div/div[2]/div/div/div[1]/ul/li[2]/div[1]/div/ul/li[1]/button")));
		driver.findElement(By.xpath("/html/body/div[9]/div/div/div[2]/div/div/div[1]/ul/li[2]/div[1]/div/ul/li[1]/button")).click();

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[9]/div/div/div[2]/div/div/div[1]/ul/li[6]/div[1]/div/ul/li[2]/button")));
		Reporter.log("Clicking End button"); 
		extentlogger.log(Status.INFO,"End button clicked - Passed");
		
		driver.findElement(By.xpath("/html/body/div[9]/div/div/div[2]/div/div/div[1]/ul/li[6]/div[1]/div/ul/li[2]/button")).click();
		screenCapture();

		String response = driver.findElement(By.xpath("/html/body/div[9]/div/div/div[2]/div/div/div[1]/ul/li[8]/div[2]/c-chat-message/c-text-view/div/lightning-formatted-rich-text/span")).getText();
		assertEquals(response,"Thanks for Contacting us. Goodbye! Have a great Day.", "Valid response received - Passed");
		String title = driver.getTitle();
		assertEquals(title,"Air India", "Valid title - Passed");
	}
}
