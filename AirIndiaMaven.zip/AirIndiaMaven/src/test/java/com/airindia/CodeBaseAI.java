package com.airindia;

import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CodeBaseAI {



	static WebDriver driver;
	List<String> deptfrom, to;


	@BeforeTest
	public void setUp() throws IOException, FileNotFoundException
	{
		InputStream file= new FileInputStream("src/test/resources/config.properties");
		Properties prop= new Properties();
		prop.load(file);
		String browser=prop.getProperty("browser_name");
		String url= prop.getProperty("URL");
		switch(browser)
		{
		case "chrome":
		{
			WebDriverManager.chromedriver().setup();
			driver= new ChromeDriver();
			break;
		}
		case "edge":
		{
			WebDriverManager.edgedriver().setup();
			driver=new EdgeDriver();
			break;
		}
		}
		driver.manage().window().maximize();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
	}



	public void screenCapture() throws IOException {
		File scrshttemp = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String ts = new SimpleDateFormat("ddMMyyyy_HHmmss").format(Calendar.getInstance().getTime());
		File scrsht = new File("screentshots\\" + ts + ".png");
		FileUtils.copyFile(scrshttemp, scrsht);

	}
	
	public ArrayList<Object[]> getExcelDataOneway() throws IOException
	{
		ArrayList<Object[]> data_oneway=new ArrayList<Object[]>();
		
		InputStream data_excel = new FileInputStream("src//test//resources//DeptFrom.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(data_excel);
		XSSFSheet sh = wb.getSheet("OneWay");
		XSSFCell cell;
		
		for (int i = 1; i<=sh.getLastRowNum(); i++) 
		{
			  
			cell = (XSSFCell) sh.getRow(i).getCell(0);
			cell.setCellType(CellType.STRING);
			String deptfrom= cell.getStringCellValue();
			
			cell = (XSSFCell) sh.getRow(i).getCell(1);
			cell.setCellType(CellType.STRING);
			String to= cell.getStringCellValue();
			
			cell = (XSSFCell) sh.getRow(i).getCell(2);
			cell.setCellType(CellType.STRING);
			String date= cell.getStringCellValue();
			
			Object ob[]= {deptfrom, to, date};
			data_oneway.add(ob);

		}
		wb.close();	
		return data_oneway;
		
	}
	
	public ArrayList<Object[]> getExcelDataRoundWay() throws IOException
	{
		ArrayList<Object[]> data_roundway=new ArrayList<Object[]>();
		
		InputStream data_excel = new FileInputStream("src//test//resources//DeptFrom.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(data_excel);
		XSSFSheet sh = wb.getSheet("RoundTrip");
		XSSFCell cell;
		
		for (int i = 1; i<=sh.getLastRowNum(); i++) 
		{
			  
			cell = (XSSFCell) sh.getRow(i).getCell(0);
			cell.setCellType(CellType.STRING);
			String deptfrom= cell.getStringCellValue();
			
			cell = (XSSFCell) sh.getRow(i).getCell(1);
			cell.setCellType(CellType.STRING);
			String to= cell.getStringCellValue();
			
			cell = (XSSFCell) sh.getRow(i).getCell(2);
			cell.setCellType(CellType.STRING);
			String departdate= cell.getStringCellValue();
			
			cell = (XSSFCell) sh.getRow(i).getCell(3);
			cell.setCellType(CellType.STRING);
			String returndate= cell.getStringCellValue();
			
			Object ob[]= {deptfrom, to, departdate, returndate};
			data_roundway.add(ob);

		}
		wb.close();	
		return data_roundway;
		
	}
	

		@DataProvider()
		public Iterator<Object[]> getTestDataOneway() throws IOException 
		{
			ArrayList<Object[]> testData = getExcelDataOneway();
			return testData.iterator();
		}
		
		
		@DataProvider()
		public Iterator<Object[]> getTestDataRoundWay() throws IOException 
		{
			ArrayList<Object[]> testDataRoundWay = getExcelDataRoundWay();
			return testDataRoundWay.iterator();
		}

		ExtentReports extentreports;
		ExtentSparkReporter extentsparkreporter;
		ExtentTest extentlogger;

		@BeforeTest
		public void extentReport()
		{
			String ts= new SimpleDateFormat("ddMMyyyy_HHmmss").format(Calendar.getInstance().getTime());
			extentreports= new ExtentReports();
			extentsparkreporter= new ExtentSparkReporter(new File("Extent reports\\"+ts+".html"));
			extentreports.attachReporter(extentsparkreporter);
		}
		
		@AfterMethod
		public void navigateTo() {
			driver.navigate().to("https://www.airindia.in/");
		}

		@AfterTest
		public void tearDown()
		{
			extentreports.flush();
			driver.quit();
		}



	
}

