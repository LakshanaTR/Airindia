package com.airindia;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.time.Duration;
import java.util.LinkedList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

public class SocialMediaLinkTest extends CodeBaseAI {
	
	@BeforeClass
	public void startExtentLogger()
	{
		extentlogger = extentreports.createTest("SocialMediaLinkTest"); 
	}
	
	@Test() 
	public void test5() throws InterruptedException, IOException {
		
		extentlogger = extentreports.createTest("Air India Social Media link test 5.");
		
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,2060)", "");
		
		Reporter.log("Clicking Instagram image button"); 
		extentlogger.log(Status.INFO,"Instagram image button clicked - Passed");
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/form[1]/div[4]/div/div[13]/div/div[1]/div[5]/div/div[1]/a[1]/img")));
		driver.findElement(By.xpath("/html/body/form[1]/div[4]/div/div[13]/div/div[1]/div[5]/div/div[1]/a[1]/img")).click();
		
		
		driver.switchTo().window(new LinkedList<String>(driver.getWindowHandles()).get(1));
		String title_insta = driver.getTitle();
		
		screenCapture();
		assertEquals(title_insta, "Air India (@airindia.in) • Instagram photos and videos", "Passed");
		driver.switchTo().window(new LinkedList<String>(driver.getWindowHandles()).get(0));

		js.executeScript("window.scrollBy(0,3060)", "");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		

		Reporter.log("Clicking FB image button"); 
		extentlogger.log(Status.INFO,"FB image button clicked - Passed");
		
		WebElement element = driver.findElement(By.xpath("/html/body/form[1]/div[4]/div/div[13]/div/div[2]/div[1]/div[2]/div[1]/a[3]/img"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);
		
		driver.switchTo().window(new LinkedList<String>(driver.getWindowHandles()).get(2));
		
		/*
		 * wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
		 * "/html/body/div[5]/div[1]/div/div[2]/div/div/div/div/div/div/div[3]/div/div/div/div/div/div"
		 * ))); driver.findElement(By.xpath(
		 * "/html/body/div[5]/div[1]/div/div[2]/div/div/div/div/div/div/div[3]/div/div/div/div/div/div"
		 * )).click();
		 */
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/div/div[1]/div/div[2]/div[2]/div[1]")));
		screenCapture();
		
		String title_FB = driver.getTitle();
		assertEquals(title_FB, "Air India - Home | Facebook", "Passed");
		
		driver.navigate().to("https://www.airindia.in/");
		
		Reporter.log("Clicking Twitter image button"); 
		extentlogger.log(Status.INFO,"Twitter image button clicked - Passed");
		WebElement element_twitter = driver.findElement(By.xpath("/html/body/form[1]/div[4]/div/div[13]/div/div[1]/div[5]/div/div[1]/a[2]/img"));
		JavascriptExecutor executor_twitter = (JavascriptExecutor)driver;
		executor_twitter.executeScript("arguments[0].click();", element_twitter);
		
		driver.switchTo().window(new LinkedList<String>(driver.getWindowHandles()).get(3));
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("/html/body/div[1]/div/div/div[2]/main/div/div/div/div/div/div[3]/div/div/div/div/div[2]/div[1]/div/div[1]/div/div/span[1]/span")));
		screenCapture();
		String title_twitter = driver.getTitle();
		assertEquals(title_twitter, "Air India (@airindiain) / Twitter", "Passed");
		
		driver.navigate().to("https://www.airindia.in/");
		Reporter.log("Clicking YouTube image button"); 
		extentlogger.log(Status.INFO,"YouTube image button clicked - Passed");
		
		WebElement element_YouTube = driver.findElement(By.xpath("/html/body/form[1]/div[4]/div/div[13]/div/div[1]/div[5]/div/div[1]/a[4]/img"));
		JavascriptExecutor executor_YouTube = (JavascriptExecutor) driver;
		executor_YouTube.executeScript("arguments[0].click();", element_YouTube);
		
		driver.switchTo().window(new LinkedList<String>(driver.getWindowHandles()).get(4));
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("/html/body/ytd-app/div[1]/ytd-page-manager/ytd-browse/div[3]/ytd-c4-tabbed-header-renderer/tp-yt-app-header-layout/div/tp-yt-app-header/div[2]/div[2]/div/div[1]/div/div[1]/ytd-channel-name/div/div/yt-formatted-string")));
		
		screenCapture();
		String title_YouTube = driver.getTitle();
		assertEquals(title_YouTube, "Air India Official - YouTube", "Passed");
		
	}
}
