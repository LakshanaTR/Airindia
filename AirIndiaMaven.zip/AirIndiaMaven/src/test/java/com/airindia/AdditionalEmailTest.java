package com.airindia;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


public class AdditionalEmailTest extends CodeBaseAI {
	
	@BeforeClass
	public void startExtentLogger()
	{
		extentlogger = extentreports.createTest("AirIndiaCheckboxTest"); 
	}
	
	LoginTest loginclass;
	@Test
	public void test10() throws InterruptedException, IOException {

		extentlogger = extentreports.createTest("Air India checkbox test 10.");
		loginclass = new LoginTest();
		loginclass.test8();
		

		driver.findElement(By.xpath("/html/body/app-root/app-lang/main-root/div/app-main-menu-pres/nav/div/div/div/a[2]")).click();
		driver.findElement(By.xpath("/html/body/app-root/app-lang/main-root/mat-sidenav-container/mat-sidenav-content/main/mat-tab-nav-panel/app-edit/app-main-layout-cont/app-main-layout-pres/div/div[2]/form/div/mat-expansion-panel[2]/div/div/app-contact-info-cont/app-contact-info-pres/form/div/div[1]/div/div[2]/button")).click();

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)", "");
		
		screenCapture();
		driver.findElement(By.xpath("/html/body/app-root/app-lang/main-root/mat-sidenav-container/mat-sidenav-content/main/mat-tab-nav-panel/app-edit/app-main-layout-cont/app-main-layout-pres/div/div[2]/form/div/mat-expansion-panel[2]/div/div/app-contact-info-cont/app-contact-info-pres/form/div/div[1]/div[2]/mat-form-field[2]/div/div[1]/div[3]/input")).sendKeys("nikkysammathew23@gmail.com");

		driver.findElement(By.xpath("/html/body/app-root/app-lang/main-root/mat-sidenav-container/mat-sidenav-content/main/mat-tab-nav-panel/app-edit/app-main-layout-cont/app-main-layout-pres/div/div[2]/form/div/mat-expansion-panel[2]/div/div/app-contact-info-cont/app-contact-info-pres/form/div/div[2]/div/div[3]/button/span[1]")).click();
		Thread.sleep(5000);


		Actions act = new Actions(driver); 
		WebElement countryCode = driver.findElement(By.xpath("/html/body/app-root/app-lang/main-root/mat-sidenav-container/mat-sidenav-content/main/mat-tab-nav-panel/app-edit/app-main-layout-cont/app-main-layout-pres/div/div[2]/form/div/mat-expansion-panel[2]/div/div/app-contact-info-cont/app-contact-info-pres/form/div/div[2]/div[2]/div[2]/autocomplete-input/mat-form-field/div/div[1]/div[3]/input")); 
		act.moveToElement(countryCode).click().sendKeys("+91").perform();

		act.moveToElement(countryCode).sendKeys(Keys.UP).perform();
		act.moveToElement(countryCode).sendKeys(Keys.ENTER).perform();
		screenCapture();
		
		WebElement mobileNumber = driver.findElement(By.xpath("/html[1]/body[1]/app-root[1]/app-lang[1]/main-root[1]/mat-sidenav-container[1]/mat-sidenav-content[1]/main[1]/mat-tab-nav-panel[1]/app-edit[1]/app-main-layout-cont[1]/app-main-layout-pres[1]/div[1]/div[2]/form[1]/div[1]/mat-expansion-panel[2]/div[1]/div[1]/app-contact-info-cont[1]/app-contact-info-pres[1]/form[1]/div[1]/div[2]/div[2]/div[2]/mat-form-field[1]/div[1]/div[1]/div[3]"));
		act.moveToElement(mobileNumber).click().sendKeys("9745035711").perform();
		screenCapture();
		
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id=\"mat-tab-nav-panel-0\"]/app-edit/app-main-layout-cont/app-main-layout-pres/div/div[2]/form/div/div/button[1]/span[1]")).click();
		Thread.sleep(4000);
	}
}
