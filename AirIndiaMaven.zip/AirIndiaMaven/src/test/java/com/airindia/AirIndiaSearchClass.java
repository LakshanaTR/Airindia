package com.airindia;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class AirIndiaSearchClass extends CodeBaseAI {
	
	By oneway = By.xpath("//*[@id=\"home\"]/div[2]/div/div[2]/div[1]/div/ins");
	By from = By.id("from");
	By Depto = By.id("to");
	By departure = By.id("_depdateeu1");
	By depdatepicker = By.xpath("/html/body/div[6]/div[2]/table/tbody/tr[2]/td[6]/a");
	By search = By.id("btnbooking");
	By askmaharaja = By.id("helpButtonSpan");
	By retrndate = By.id("_retdateeu1");
	
	
public void onewayClick() 
{
	driver.findElement(oneway).click();
}

public void typeFrom(String deptfrom) 
{
	driver.findElement(from).sendKeys(deptfrom);
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
}

public void typeto(String to) 
{
	driver.findElement(Depto).sendKeys(to);
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
}

public void departureDateType(String date) 
{
	driver.findElement(departure).sendKeys(date);
}

public void returnDateType(String returndate) 
{
	driver.findElement(retrndate).sendKeys(returndate);
}

public void childrenSelect() 
{
	WebElement children = driver.findElement(By.id("ddlchildren1"));
	Select child = new Select(children);
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
	child.selectByIndex(2);
}
public void infantSelect() 
{
	WebElement infant = driver.findElement(By.id("ddlinfants1"));
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
	Select infantSelect = new Select(infant);
	infantSelect.selectByIndex(1);
}


public void searchButtonClick() 
{
	driver.findElement(search).click();
}
public void askmaharajaClick() 
{
	driver.findElement(askmaharaja).click();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4));
	
}


}
