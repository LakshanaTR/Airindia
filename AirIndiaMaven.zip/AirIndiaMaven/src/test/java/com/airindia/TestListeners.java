package com.airindia;

import java.io.IOException;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

import com.aventstack.extentreports.Status;

public class TestListeners extends CodeBaseAI implements ITestListener
{
	
	@Override
	public void onTestFailure(ITestResult result)
	{	
	
		Reporter.log("Test falied "+ result.getName());
		extentlogger.log(Status.FAIL, "Test Failed" + result.getName());
		try 
		{
			screenCapture();
		} 
		catch (IOException e) 
		{
			
			e.printStackTrace();
		}
	}

	@Override
	public void onStart(ITestContext context)
	{	
		
		Reporter.log("Test started");
		extentlogger.log(Status.INFO, "Test started");
	}
	
	@Override
	public void onFinish(ITestContext context)
	{	
		
		Reporter.log("Test finished");
		extentlogger.log(Status.INFO, "Test finished");
	}
}
