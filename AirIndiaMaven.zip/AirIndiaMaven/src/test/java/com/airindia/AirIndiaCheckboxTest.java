package com.airindia;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

public class AirIndiaCheckboxTest extends CodeBaseAI {
	
	LoginTest loginclass;
	
	@BeforeClass
	public void startExtentLogger()
	{
		extentlogger = extentreports.createTest("AirIndiaCheckboxTest"); 
	}
	
	@Test()
	public void test9() throws InterruptedException, IOException {
		
		extentlogger = extentreports.createTest("Air India checkbox test 9.");
		loginclass = new LoginTest();
		
		//Calling Login Method
		loginclass.test8();
		driver.findElement(By.xpath("/html/body/app-root/app-lang/main-root/div/app-main-menu-pres/nav/div/div/div/a[2]")).click();
		String checkbox = driver.findElement(By.xpath("/html/body/app-root/app-lang/main-root/mat-sidenav-container/mat-sidenav-content/main/mat-tab-nav-panel/app-edit/app-main-layout-cont/app-main-layout-pres/div/div[2]/form/div/mat-expansion-panel[4]/div/div/app-preference-info-cont/app-preference-info-pres/form/div/section/div")).getText();
		System.out.println(checkbox);
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,3060)", "");
		
		Reporter.log("Clicking business and industry checkbox."); 
		extentlogger.log(Status.INFO,"Business and industry checkbox clicked- Passed");
		
		js.executeScript("arguments[0].click()", driver.findElement(By.xpath(("(//input[@type='checkbox'])[1]"))));
		WebElement business = driver.findElement(By.xpath(("(//input[@type='checkbox'])[1]")));
		System.out.println("Is business & industry checkbox checked? " + business.isSelected());
		
		screenCapture();
		
		Reporter.log("Clicking travel & leisure checkbox."); 
		extentlogger.log(Status.INFO,"Travel & leisure checkbox - Passed");	
		
		js.executeScript("arguments[0].click()", driver.findElement(By.xpath(("//*[@id=\"mat-checkbox-10-input\"]"))));
		WebElement travel = driver.findElement(By.xpath("//*[@id=\"mat-checkbox-10-input\"]"));
		
		screenCapture();
		System.out.println("Is travel & leisure checkbox checked? " + travel.isSelected());


	}
}