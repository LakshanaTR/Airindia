package com.airindia;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

public class SearchFeatureTest2 extends CodeBaseAI {
	
	AirIndiaSearchClass searchClass;
	
	@BeforeClass
	public void startExtentLogger()
	{
		extentlogger = extentreports.createTest("SearchFeatureTest2"); 
		searchClass = new AirIndiaSearchClass();
	}
	
	@Test(dataProvider = "getTestDataRoundWay")
	public void test2(String deptfrom, String to, String departdate, String returndate) throws IOException, InterruptedException 
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(35));
		extentlogger = extentreports.createTest("Air India search feature test 2.");
		
		Reporter.log("Loading Test Data."); 
		extentlogger.log(Status.INFO,"Loading Test Data Passed");
		
		searchClass.typeFrom(deptfrom);
		searchClass.typeto(to);
		searchClass.departureDateType(departdate);
		searchClass.returnDateType(returndate);
		
		Reporter.log("Selecting number of children from children dropdown."); 
		extentlogger.log(Status.INFO,"Selecting number of children from children dropdown - Passed");
		searchClass.childrenSelect();
		
		Reporter.log("Selecting number of infants from infant dropdown."); 
		extentlogger.log(Status.INFO,"Selecting number of infants from infant dropdown - Passed");
		searchClass.infantSelect();
		
		searchClass.searchButtonClick();
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/app/refx-app-layout/div/div[2]/refx-upsell/refx-basic-in-flow-layout/div/div[3]/refx-page-title-pres/div/picture/img")));
		
		Reporter.log("Redirection to flight selection page.");
		extentlogger.log(Status.INFO, "Redirection to flight selection page - Passed");
		
		screenCapture();

		String title = driver.getTitle();
		assertEquals(title, "Flight selection", "Flight selection page loaded - Passed");
		driver.navigate().to("https://www.airindia.in/");
	}
}
