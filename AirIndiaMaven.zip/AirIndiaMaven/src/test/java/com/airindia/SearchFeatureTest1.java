package com.airindia;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;


public class SearchFeatureTest1 extends CodeBaseAI {

	AirIndiaSearchClass searchClass;

	@BeforeClass
	public void startExtentLogger()
	{
		extentlogger = extentreports.createTest("SearchFeatureTest1"); 
		searchClass = new AirIndiaSearchClass();
	}

	@Test(dataProvider ="getTestDataOneway")
	public void SearchFeature1(String deptfrom, String to, String date) throws IOException, InterruptedException {
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(35));

		extentlogger = extentreports.createTest("Air India search feature test.");
		
		Reporter.log("Clicking one way button."); 
		extentlogger.log(Status.INFO,"Clicking one way button - passed");
		
		searchClass.onewayClick(); 

		screenCapture();
		Reporter.log("Loading data and sending to from text box");
		extentlogger.log(Status.INFO, "Loading data and sending to from text box");
		
		searchClass.typeFrom(deptfrom);
		searchClass.typeto(to);
		searchClass.departureDateType(date);
		
		Reporter.log("Selecting number of children from children dropdown option");
		extentlogger.log(Status.INFO, "Selecting number of children from children dropdown option - Passed");
		
		searchClass.childrenSelect();
		searchClass.infantSelect();
		searchClass.searchButtonClick();
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/app/refx-app-layout/div/div[2]/refx-upsell/refx-basic-in-flow-layout/div/div[3]/refx-page-title-pres/div/picture/img")));
		screenCapture();
		
		WebElement backgroundImage  = driver.findElement(By.xpath("/html/body/app/refx-app-layout/div/div[2]/refx-upsell/refx-basic-in-flow-layout/div/div[3]/refx-page-title-pres/div/picture/img"));
		System.out.println("Is flight selection background image displayed? " + backgroundImage.isDisplayed());
		
		Reporter.log("Redirection to flight selection page.");
		extentlogger.log(Status.INFO, "Redirection to flight selection page - Passed");
		
		screenCapture();
		String title = driver.getTitle();
		assertEquals(title, "Flight selection", "Flight selection page loaded - Passed");
		driver.navigate().to("https://www.airindia.in/");


	}

	

}

