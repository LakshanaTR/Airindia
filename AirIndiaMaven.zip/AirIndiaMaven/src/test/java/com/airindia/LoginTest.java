package com.airindia;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.time.Duration;
import java.util.LinkedList;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

public class LoginTest extends CodeBaseAI{
	
	@BeforeClass
	public void startExtentLogger()
	{
		extentlogger = extentreports.createTest("Login test 8"); 
	}
	
	@Test()
	public void test8() throws InterruptedException, IOException {
		
		extentlogger = extentreports.createTest("Air India Login test 8.");
	
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/form[1]/div[4]/div/div[5]/div/div/div[2]/ul/li[3]/a/img")));
		
		driver.findElement(By.xpath("/html/body/form[1]/div[4]/div/div[5]/div/div/div[2]/ul/li[3]/a/img")).click();
		
		Reporter.log("Redirecting to login page."); 
		extentlogger.log(Status.INFO,"Login page loaded - Passed");
		screenCapture();
		
		driver.switchTo().window(new LinkedList<String>(driver.getWindowHandles()).get(1));
		wait.until(ExpectedConditions.elementToBeClickable(By.id("signInName")));
		
		driver.findElement(By.id("signInName")).sendKeys("nikkysammathew8@gmail.com");	
		driver.findElement(By.id("password")).sendKeys("@Romans5:6");
		driver.findElement(By.id("next")).click();
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/app-root/app-lang/main-root/div/app-main-menu-pres/nav/div/div/div/a[1]")));
		
		screenCapture();
		Reporter.log("Redirecting to account summary page."); 
		extentlogger.log(Status.INFO,"Account Summary page loaded - Passed");
		
		String title = driver.getTitle();
		assertEquals(title, "Account Summary | Air India", "Login successful - Passed");
	}
}
