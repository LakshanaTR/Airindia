package com.airindia;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

public class FlightScheduleTest extends CodeBaseAI {
	
	@BeforeClass
	public void startExtentLogger()
	{
		extentlogger = extentreports.createTest("FlightScheduleTest"); 
	}
	
	@Test()
	public void test7() throws InterruptedException {
		
		extentlogger = extentreports.createTest("Air India Flight Schedule link test 7.");
		
		Actions act = new Actions(driver);
		act.click().perform();
		
		//move to an element
		WebElement manage = driver.findElement(By.xpath("/html/body/form[1]/div[4]/div/div[5]/div/div/div[1]/ul/li[1]/a"));
		act.moveToElement(manage).perform();
		
		
		driver.findElement(By.xpath("/html/body/form[1]/div[4]/div/div[5]/div/div/div[1]/ul/li[1]/div/ul/li[2]/a")).click();
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1060)", "");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/form[1]/div[4]/div/div[7]/div/div/span/div/div/div[2]/div/div[2]/div[1]/table/tbody/tr/td[1]/div/ins")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("txtFromDate")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[6]/table/tbody/tr[5]/td[6]/a")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("txtFromLocation")).sendKeys("Delhi, Indira Gandhi International Airport, DEL, India");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		driver.findElement(By.id("txtToLocation")).sendKeys("Mumbai, Chhatrapati Shivaji International Airport, BOM, India");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		Thread.sleep(3000);
		act.sendKeys(Keys.DOWN).build().perform();
		act.sendKeys(Keys.ENTER).build().perform();
		

		Reporter.log("Clicking Submit button"); 
		extentlogger.log(Status.INFO,"Submit button clicked - Passed");
		
		driver.findElement(By.id("btnFlightTimeTable")).click();
		Thread.sleep(6000);
		
		String title=driver.getTitle();
		System.out.println(title);
		
	}

}
